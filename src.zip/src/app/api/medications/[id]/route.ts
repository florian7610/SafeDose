// src/app/api/medications/[id]/route.ts
import { NextResponse } from "next/server";
import connectToDatabase from "@/lib/mongodb";
import { requireRole } from "@/lib/auth";
import Patient from "@/data/models/Patient";
import Medication from "@/data/models/Medication";
import { dosesPerDay, parseTakenIndices, toggleTakenIndex } from "@/lib/medication-utils";

function todayStr() {
  return new Date().toISOString().split("T")[0];
}

function serializeMed(m: any) {
  const today  = todayStr();
  const dpd    = dosesPerDay(m.frequency);
  const taken  = parseTakenIndices(m.takenDoses ?? null, today);
  return {
    id:           m._id.toString(),
    patientId:    m.patientId.toString(),
    addedBy:      m.addedBy?.toString() ?? null,
    name:         m.name,
    genericName:  m.genericName,
    dosage:       m.dosage,
    frequency:    m.frequency,
    scheduleTime: m.scheduleTime,
    status:       m.status,
    rxcui:        m.rxcui ?? "",
    dosesPerDay:  dpd,
    takenIndices: taken,
    takenToday:   taken.length >= dpd,
    startDate:    m.startDate?.toISOString() ?? null,
    endDate:      m.endDate?.toISOString()   ?? null,
    isOngoing:    m.isOngoing ?? true,
    stoppedAt:    m.stoppedAt?.toISOString() ?? null,
    createdAt:    m.createdAt,
    updatedAt:    m.updatedAt,
  };
}

/**
 * PATCH /api/medications/[id]
 *
 * To toggle a single dose:   { doseIndex: 0, taken: true }
 * To update clinical fields: { dosage, frequency, scheduleTime, status, startDate, endDate, isOngoing }
 * status "stopped" automatically sets stoppedAt.
 */
export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const caller = await requireRole("patient", "admin");
  if (!caller) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  await connectToDatabase();

  const patient = await Patient.findOne({ linkedUserId: caller.userId });
  if (!patient) return NextResponse.json({ message: "Patient profile not found" }, { status: 404 });

  const body = await req.json();
  const safe: Record<string, any> = {};

  // ── Dose toggle ──────────────────────────────────────────────────────────
  if (typeof body.doseIndex === "number" && typeof body.taken === "boolean") {
    const current = await Medication.findOne({ _id: id, patientId: patient._id });
    if (!current) return NextResponse.json({ message: "Medication not found" }, { status: 404 });
    safe.takenDoses = toggleTakenIndex(current.takenDoses ?? null, todayStr(), body.doseIndex, body.taken);
  }

  // ── Clinical fields ───────────────────────────────────────────────────────
  const ALLOWED = ["dosage", "frequency", "scheduleTime", "status", "startDate", "endDate", "isOngoing"];
  for (const [k, v] of Object.entries(body)) {
    if (ALLOWED.includes(k)) safe[k] = v;
  }
  if (safe.status === "stopped") safe.stoppedAt = new Date();
  if (safe.isOngoing === true) safe.endDate = null;

  const med = await Medication.findOneAndUpdate(
    { _id: id, patientId: patient._id },
    { $set: safe },
    { new: true }
  );

  if (!med) return NextResponse.json({ message: "Medication not found" }, { status: 404 });
  return NextResponse.json(serializeMed(med));
}

/**
 * DELETE /api/medications/[id] — hard-deletes (accidental entry).
 * To soft-stop, PATCH with { status: "stopped" }.
 */
export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const caller = await requireRole("patient", "admin");
  if (!caller) return NextResponse.json({ message: "Unauthorized" }, { status: 401 });

  const { id } = await params;
  await connectToDatabase();

  const patient = await Patient.findOne({ linkedUserId: caller.userId });
  if (!patient) return NextResponse.json({ message: "Patient profile not found" }, { status: 404 });

  const deleted = await Medication.findOneAndDelete({ _id: id, patientId: patient._id });
  if (!deleted) return NextResponse.json({ message: "Medication not found" }, { status: 404 });
  return NextResponse.json({ message: "Medication deleted" }, { status: 200 });
}
